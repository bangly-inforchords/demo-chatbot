import * as React from 'react';
import styles from './Chatbot.module.scss';
import type { IChatbotProps } from './IChatbotProps';
import { FontIcon } from '@fluentui/react';

export default class Chatbot extends React.Component<IChatbotProps> {
  public render(): React.ReactElement<IChatbotProps> {
    const { redirectUrl } = this.props;

    return (
      <>
        <a href={redirectUrl} className={styles.float}>
          <FontIcon className={styles.myfloat} iconName='Robot'>chatbot</FontIcon>
        </a>
      </>
    );
  }
}
