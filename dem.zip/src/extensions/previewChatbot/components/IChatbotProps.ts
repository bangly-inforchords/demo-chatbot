export interface IChatbotProps {
  redirectUrl: string;
}
