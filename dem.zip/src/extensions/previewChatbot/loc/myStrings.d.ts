declare interface IPreviewChatbotApplicationCustomizerStrings {
  Title: string;
}

declare module 'PreviewChatbotApplicationCustomizerStrings' {
  const strings: IPreviewChatbotApplicationCustomizerStrings;
  export = strings;
}
