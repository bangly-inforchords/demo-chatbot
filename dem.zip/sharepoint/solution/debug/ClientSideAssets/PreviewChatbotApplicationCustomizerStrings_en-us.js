define([], function() {
  return {
    "Title": "PreviewChatbotApplicationCustomizer"
  }
});