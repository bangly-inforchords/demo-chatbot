import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  type IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IReadonlyTheme } from '@microsoft/sp-component-base';

import * as strings from 'ChatbotWebPartStrings';
import Chatbot from './components/Chatbot';
import { IChatbotProps } from './components/IChatbotProps';

export interface IChatbotWebPartProps {
  redirectUrl: string;
  logoUrl: string;
  iconSize: string;
}

export default class ChatbotWebPart extends BaseClientSideWebPart<IChatbotWebPartProps> {

  private _environmentMessage: string = '';

  public renderStyling = (): HTMLElement => {
    const style = document.createElement('style');
    style.innerHTML = `
      div:has(> div > div > [data-sp-feature-tag^="Chatbot"]) {
        background-color: #ff7600;
        height: 0px;
        margin: 0px!important;
        padding: 0px!important;
      }
      div.CanvasSection:has(div > div > [data-sp-feature-tag^="Chatbot"]) {
        background-color: #ff7600;
        height: 0px;
        margin: 0px!important;
        padding: 0px!important;
      }
    `;
    return style;
  }

  public render(): void {
    const element: React.ReactElement<IChatbotProps> = React.createElement(
      Chatbot,
      {
        redirectUrl: this.properties.redirectUrl,
        logoUrl: this.properties.logoUrl,
        iconSize: this.properties.iconSize,
      }
    );

    ReactDom.render(element, this.domElement);
    this.domElement.appendChild(this.renderStyling());
  }

  protected onInit(): Promise<void> {
    return this._getEnvironmentMessage().then(message => {
      this._environmentMessage = message;
      console.log(this._environmentMessage);
    });
  }



  private _getEnvironmentMessage(): Promise<string> {
    if (!!this.context.sdks.microsoftTeams) { // running in Teams, office.com or Outlook
      return this.context.sdks.microsoftTeams.teamsJs.app.getContext()
        .then(context => {
          let environmentMessage: string = '';
          switch (context.app.host.name) {
            case 'Office': // running in Office
              environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentOffice : strings.AppOfficeEnvironment;
              break;
            case 'Outlook': // running in Outlook
              environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentOutlook : strings.AppOutlookEnvironment;
              break;
            case 'Teams': // running in Teams
            case 'TeamsModern':
              environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentTeams : strings.AppTeamsTabEnvironment;
              break;
            default:
              environmentMessage = strings.UnknownEnvironment;
          }

          return environmentMessage;
        });
    }

    return Promise.resolve(this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentSharePoint : strings.AppSharePointEnvironment);
  }

  protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void {
    if (!currentTheme) {
      return;
    }
    const {
      semanticColors
    } = currentTheme;

    if (semanticColors) {
      this.domElement.style.setProperty('--bodyText', semanticColors.bodyText || null);
      this.domElement.style.setProperty('--link', semanticColors.link || null);
      this.domElement.style.setProperty('--linkHovered', semanticColors.linkHovered || null);
    }

  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('redirectUrl', {
                  label: strings.RedirectUrlFieldLabel
                }),
                PropertyPaneTextField('logoUrl', {
                  label: strings.LogoUrlFieldLabel
                }),
                PropertyPaneTextField('iconSize', {
                  label: strings.IconSizeFieldLabel,
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
