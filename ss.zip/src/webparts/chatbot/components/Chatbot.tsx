import * as React from 'react';
import styles from './Chatbot.module.scss';
import type { IChatbotProps } from './IChatbotProps';

// eslint-disable-next-line @typescript-eslint/no-var-requires
const defaultLogo: string = require('../assets/icon.svg'); 

export default class Chatbot extends React.Component<IChatbotProps> {
  public render(): React.ReactElement<IChatbotProps> {
    const { redirectUrl, logoUrl, iconSize } = this.props;

    return (
      <>
        <a href={redirectUrl} className={styles.float} rel="noreferrer" target={'_blank'}>
          <img className={styles.myfloat} style={{ width: iconSize || "100%", height: "auto" }} src={logoUrl || defaultLogo} alt="test" />
        </a>
      </>
    );
  }
}
