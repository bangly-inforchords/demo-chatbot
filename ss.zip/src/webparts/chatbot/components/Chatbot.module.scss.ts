
require("./Chatbot.module.css");
const styles = {
  chatbot: 'chatbot_d3bf65dd',
  teams: 'teams_d3bf65dd',
  welcome: 'welcome_d3bf65dd',
  welcomeImage: 'welcomeImage_d3bf65dd',
  links: 'links_d3bf65dd',
  float: 'float_d3bf65dd',
  myfloat: 'myfloat_d3bf65dd'
};

export default styles;
