export interface IChatbotProps {
  redirectUrl: string;
  logoUrl: string;
  iconSize: string;
}
