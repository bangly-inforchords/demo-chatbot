import * as React from 'react';
import type { IChatbotProps } from './IChatbotProps';
export default class Chatbot extends React.Component<IChatbotProps> {
    render(): React.ReactElement<IChatbotProps>;
}
//# sourceMappingURL=Chatbot.d.ts.map