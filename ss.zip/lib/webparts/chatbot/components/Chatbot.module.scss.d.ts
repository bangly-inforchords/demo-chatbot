declare const styles: {
    chatbot: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
    float: string;
    myfloat: string;
};
export default styles;
//# sourceMappingURL=Chatbot.module.scss.d.ts.map